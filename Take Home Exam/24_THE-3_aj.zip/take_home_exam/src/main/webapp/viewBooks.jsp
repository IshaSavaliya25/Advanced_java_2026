<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<!DOCTYPE html>
<html>
<head>
    <title>View Books</title>
    <style>
        body {
            font-family: Arial;
            background: #f4f6f9;
        }
        .container {
            width: 80%;
            margin: auto;
            margin-top: 40px;
            background: white;
            padding: 20px;
            border-radius: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            text-align: center;
        }
        th {
            background: #667eea;
            color: white;
        }
        tr:hover {
            background: #f1f1f1;
        }
        a {
            display: inline-block;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

<div class="container">

    <a href="addBook.jsp">Back</a>

    <h2>Book List</h2>

    <table>
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Author</th>
            <th>Quantity</th>
        </tr>

        <c:forEach var="b" items="${bookList}">
            <tr>
                <td>${b.bookId}</td>
                <td>${b.title}</td>
                <td>${b.author}</td>
                <td>${b.quantity}</td>
            </tr>
        </c:forEach>

    </table>

</div>

</body>
</html>