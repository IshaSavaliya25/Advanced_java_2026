package main;

import dao.BookDAO;
import model.Book;

public class MainApp {
    public static void main(String[] args) {

        BookDAO dao = new BookDAO();

        dao.addBook(new Book("Java Programming", "James Gosling", 10));

        dao.getAllBooks().forEach(b ->
                System.out.println(b.getBookId() + " " + b.getTitle())
        );

        dao.searchBook("Java").forEach(b ->
                System.out.println("Found: " + b.getTitle())
        );

        dao.updateBook(1, 20);

        dao.deleteBook(2);
    }
}