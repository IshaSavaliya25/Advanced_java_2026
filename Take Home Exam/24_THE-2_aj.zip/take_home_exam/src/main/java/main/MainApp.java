package main;

import dao.BookDAO;
import model.Book;

public class MainApp {
    public static void main(String[] args) {

        BookDAO dao = new BookDAO();

        // ADD
        dao.addBook(new Book("Java Programming", "James Gosling", 10));

        // VIEW
        dao.getAllBooks().forEach(b ->
                System.out.println(b.getBookId() + " " + b.getTitle())
        );

        // SEARCH
        dao.searchBook("Java").forEach(b ->
                System.out.println("Found: " + b.getTitle())
        );

        // UPDATE
        dao.updateBook(1, 20);

        // DELETE
        dao.deleteBook(2);
    }
}