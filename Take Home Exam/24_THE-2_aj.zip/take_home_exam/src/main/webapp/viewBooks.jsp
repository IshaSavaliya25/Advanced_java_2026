<%@ page import="java.util.*, model.Book" %>

<!DOCTYPE html>
<html>
<head>
    <title>View Books</title>
    <style>
        body {
            font-family: Arial;
            background: #f4f6f9;
        }
        .container {
            width: 80%;
            margin: auto;
            margin-top: 40px;
            background: white;
            padding: 20px;
            border-radius: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            text-align: center;
        }
        th {
            background: #667eea;
            color: white;
        }
        tr:hover {
            background: #f1f1f1;
        }
        a {
            display: inline-block;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

<div class="container">

    <a href="addBook.jsp">Back</a>

    <h2>Book List</h2>

    <table>
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Author</th>
            <th>Quantity</th>
        </tr>

        <%
            List<Book> list = (List<Book>) request.getAttribute("bookList");
            if(list != null){
                for(Book b : list){
        %>
        <tr>
            <td><%= b.getBookId() %></td>
            <td><%= b.getTitle() %></td>
            <td><%= b.getAuthor() %></td>
            <td><%= b.getQuantity() %></td>
        </tr>
        <%
                }
            }
        %>

    </table>

</div>

</body>
</html>